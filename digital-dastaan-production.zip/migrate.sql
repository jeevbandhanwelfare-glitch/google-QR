-- Digital Dastaan Review Generator — Database Setup
-- Run this in your PostgreSQL database ONCE before starting the server.
-- Safe to re-run: uses IF NOT EXISTS.

CREATE TABLE IF NOT EXISTS clients (
  id                      SERIAL PRIMARY KEY,
  name                    TEXT NOT NULL,
  slug                    TEXT NOT NULL UNIQUE,
  location                TEXT NOT NULL,
  business_type           TEXT NOT NULL,
  google_review_url       TEXT NOT NULL,
  logo_url                TEXT,
  description             TEXT,
  is_active               BOOLEAN NOT NULL DEFAULT TRUE,
  subscription_expires_at TIMESTAMPTZ,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-update updated_at on every row change
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_clients_updated_at ON clients;
CREATE TRIGGER set_clients_updated_at
  BEFORE UPDATE ON clients
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
