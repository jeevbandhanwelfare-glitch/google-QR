# Digital Dastaan Review Generator — Hostinger Deployment Guide

## What You Need

| Requirement | Details |
|-------------|---------|
| Node.js | v20 or higher |
| PostgreSQL | v14 or higher |
| OpenAI API key | Get one at https://platform.openai.com/api-keys |

---

## Step-by-Step Deployment

### 1. Upload Files

Upload the **entire contents** of this ZIP to your Hostinger Node.js hosting
directory (e.g. `/home/youruser/htdocs/yourdomain.com/`).

### 2. Set Up the Database

In Hostinger's control panel, create a PostgreSQL database and note down:
- Host, Port, Database name, Username, Password

Connect to the database and run `migrate.sql` to create the tables:

```bash
psql -h HOST -U USERNAME -d DATABASE_NAME -f migrate.sql
```

Or copy-paste the SQL into Hostinger's database manager (phpPgAdmin).

### 3. Configure Environment Variables

In Hostinger → Node.js → your app → Environment Variables, add:

| Variable | Value |
|----------|-------|
| `DATABASE_URL` | `postgresql://user:pass@host:5432/dbname` |
| `OPENAI_API_KEY` | Your OpenAI key (starts with `sk-`) |
| `PORT` | `3000` (or whatever Hostinger assigns) |
| `NODE_ENV` | `production` |

Or copy `.env.example` to `.env` and fill in the values if running manually.

### 4. Set the Entry Point

In Hostinger's Node.js panel:
- **Startup file / Entry point**: `server.mjs`
- **Node.js version**: 20 or higher

### 5. Start the App

Click **Restart** in Hostinger's Node.js panel, or run:

```bash
node server.mjs
```

Your app is now live at your domain!

---

## App URLs

| URL | Purpose |
|-----|---------|
| `https://yourdomain.com/` | Marketing landing page |
| `https://yourdomain.com/admin` | Admin dashboard |
| `https://yourdomain.com/social-bulls` | Example client review page |

## Adding Clients

1. Go to `/admin`
2. Click **Add Client**
3. Fill in the business name, slug, Google Review URL, etc.
4. The review page URL (e.g. `https://yourdomain.com/social-bulls`) is what goes into the QR code

## Google Review URL Format

Use one of these formats:
- `https://search.google.com/local/writereview?placeid=YOUR_PLACE_ID`
- `https://g.page/r/YOUR_ID/review`

---

Built with ❤️ by Digital Dastaan
